export interface Alumno {
  id: number;
  nombre: string;
  mail: string;
  curso: string;
  repetidor: string;
  observaciones: string;
}
